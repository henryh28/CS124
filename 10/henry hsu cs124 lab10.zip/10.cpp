#include <iostream>
#include <fstream>
#include <map>
#include <iomanip>
#include <vector>
#include <algorithm>

using namespace std;

class StringCounter
{
	public:
		StringCounter():value(0) {}
		void operator++ (int) {value++;}	// increments word count

		int value;
};

ostream& operator<<(ostream& Word, StringCounter& WordFrequency)
{ return Word << WordFrequency.value;}

bool compare(const pair<string,StringCounter> &p1, const pair<string, StringCounter> &p2)
{
	int one, two;
	one = p1.second.value;
	two = p2.second.value;

	return one > two;
}

int main()
{
	map<string, StringCounter> data;

	// Below block opens default text file for input.
	ifstream input;
	input.open("test.txt");
	if (!input)	{cout << "Error opening file. Exiting program." << endl;}

	string word;
	while (true)
	{
		input >> word;	// Feeds text file into string "word"
		if (input) {data[word]++;}	// Increment the word currently being inputted
		else break;
	}

	map<string,StringCounter,less<string> >::iterator iter;		//creates iterator

	//Below outputs content of the map elements

	cout << "----- Below is the keys and values from the map object -----" << endl << endl;

	int i = 0;
	for (iter = data.begin(); iter != data.end(); iter++)
	{
		i += 1;
		if (i % 4 == 0) {cout << endl;}
		cout << left << setw(15) << (*iter).first << left << setw (4) << (*iter).second;
	}

	// Below creates and fills vector with value from map object, then sorts by frequency
	vector <pair<string, StringCounter> > vector_data(data.begin(), data.end());
	cout << endl << endl;
	sort (vector_data.begin(), vector_data.end(), compare);


	// Below outputs the sorted content of the vector
	cout << "----- Below is the sorted output from the vector -----" << endl << endl;
	int j = 0;
	for (int i = 0; i < vector_data.size(); i++)
	{
		j += 1;
		if (i % 4 == 0) {cout << endl;}
		cout << left << setw(15) << vector_data[i].first << left << setw (4) << vector_data[i].second;
	}

}
