#include <iostream>
#include <ctime>
#include <cstdlib>
#include <iomanip>
#include <algorithm>

using namespace std;

int main ()
{
   int array_size = 1, max_value = 1, search_amount = 1, output = 1;
   int total_guess = 0, success = 0, total_failed = 0, failed_search = 0;


   cout << left << setw(75) << "Please enter the size of the array as an integer value (max of 100): ";
   cin >> array_size;
   if (array_size > 100) {array_size = 100;}			// ensures maximum size of array

   cout << left << setw(75) << "Please enter the maximum integer value allowed in the array: ";
   cin >> max_value;

   cout << left << setw(75) << "How many times would you like to search for a random value? ";
   cin >> search_amount;

   cout << left << setw(75) << "Enable detailed output? (Enter 1 for yes, any other key for no): ";
   cin >> output;

   int lab3[array_size];

   srand(time(0));								// ensures random seed for rand loop

   for (int i = 0; i < array_size; i++)
   {
      lab3[i] = rand() % max_value +1;
   }

   sort (lab3, lab3 + array_size);				// sorts the array in ascending fashion

   cout << endl;

   if (output == 1)
   {
      for (int i = 0; i < array_size; i++)			// displays the sorted array
      {
         if (output == 1)
         {
            if (i % 10 == 0) {cout << endl;}
            cout << right << setw(10) << lab3[i] ;
	     }
      }
   }

   cout << endl << "Sorted array with size of " << array_size << " and maximum value of " << max_value << " created."<< endl << endl;

   for (int i = 0; i < search_amount; i++)			// loop through entirety of array
   {
      int fail = 0, k = 0;
      int guess = rand() % max_value + 1;		// the number to guess for on this loop

      if (output == 1)
	  {
         cout << "Searching for number: " << guess << endl;
      }
      for (int j = 0; j < max_value; j++)
      {
         if (guess == lab3[k])
         {
            if (output == 1)
            {
               cout << "It took " << fail + 1 << " tries to locate " << guess << endl;
            }
            total_guess = total_guess + (fail + 1);
 			success = success++;
            break;
         }
         else
         {
            k = k++;
            fail++;
            if (fail == array_size)
            {
               if (output == 1)
               {
                  cout << "Failed to locate " << guess << " for " << fail << " attempts" << endl;
               }
               break;
            }
	       if (guess < lab3[k])
	       {
                  if (output == 1)
                  {
		     cout << "Aborting search.  Next Array index value is: " << lab3[k] << endl;
                  }
	       total_failed = total_failed + k;
	       failed_search = failed_search++;
	       break;
	       }
         }
      }
   }
   cout << endl;
   int failed_amount = (search_amount - success) * array_size ;

   cout << left << setw(75) << "Average number of searches to locate query (sucessful searches only): " << (total_guess / success) << endl;
   cout << left << setw(75) << "Average number of searches to locate query (all searches): " << (total_guess + failed_amount) / search_amount << endl;
   cout << left << setw(75) << "Average number of array indexes that were searched for a failed search: " << total_failed / failed_search << endl;
   return 0;
}


