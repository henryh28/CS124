#include <iostream>
#include <list>
#include "date.cpp"
using namespace std;


class Lab
{
	public:
		Lab();
		Lab(string description, Date assigned, Date due);
		Date Return_Date();
		void Display_Assigned(list <Lab>& hw_tracker);
		void Remove_Assignment(list <Lab>& hw_tracker);


	private:
		string m_description;
		Date m_due;
		Date m_assigned;
};

Lab::Lab () {}

Lab::Lab (string description, Date assigned, Date due)
{
	m_description = description;
	m_assigned = assigned;
	m_due = due;
}

Date Lab::Return_Date()
{
	return m_due;
}


void Lab::Display_Assigned(list <Lab>& hw_tracker)
{
	cout << right << m_description << endl;
	cout << right << m_assigned << endl;
	cout << right << m_due << endl;
}

void Lab::Remove_Assignment(list <Lab>& hw_tracker)
{

}


string main_menu()
{
	string menu_option;

	cout << "--------------------------------" << endl;
	cout << "Welcome to Homework Tracker v1.0" << endl;
	cout << "--------------------------------" << endl;
	cout << left << setw(38) << "A)dd a new assignment" ;
	cout << "R)emove an assignment" << endl;
	cout << left << setw(38) << "L)ist assignments in order assigned";
	cout << "F)ind assignment with earliest due date" << endl;
	cout << "Q)uit" << endl;
	cin >> menu_option;
	cout << endl;
	menu_option[0] = toupper(menu_option [0]);
	menu_option.resize(1);
	return menu_option;
}


void add_assignment(list <Lab>& hw_tracker)
{
	string input_description;
	Date input_assigned, input_due;

	cout << "Enter a short description for the assignment: ";
	cin >> input_description;
	cout << "Enter the date that this assignment was assigned: ";
	cin >> input_assigned;
	cout << "Enter the date that this assignemnt is due: ";
	cin >> input_due;

	Lab assignment (input_description, input_assigned, input_due);
//	assignment.Display_Assigned(hw_tracker);
	hw_tracker.push_back(assignment);
//	hw_tracker()->Display_Assigned(hw_tracker);

//	cout << hw_tracker.size();
}


void list_assignments(list <Lab>& hw_tracker)
{
	list<Lab>::iterator iter;

	for (iter = hw_tracker.begin(); iter != hw_tracker.end(); iter++)
	{
		cout << hw_tracker.size() << endl;
// 		hw_tracker(iter)->Display_Assigned(hw_tracker);
//		temp = hw_tracker();
	}

}


void remove_assignment(list <Lab>& hw_tracker)
{
	hw_tracker.pop_back();
}


void find_earliest(list <Lab>& hw_tracker)
{
	hw_tracker.sort();



	list<Lab>::iterator iter;



	for (iter = hw_tracker.begin(); iter != hw_tracker.end(); iter++)
	{
		if(hw_tracker()->Return_Date < today)

	}
}



int main ()
{
	list <Lab> hw_tracker;

	string menu_option;

	while (menu_option != "Q")
	{
		menu_option = main_menu();

		if (menu_option == "A")
		{
			add_assignment(hw_tracker);
		}
		else if (menu_option == "R")
		{
			remove_assignment(hw_tracker);
		}
		else if (menu_option == "L")
		{
			list_assignments(hw_tracker);
		}
		else if (menu_option == "F")
		{
			find_earliest(hw_tracker);
		}
	}

cout << endl << "Thank you for using Homework Tracker v1.0" << endl;

}


