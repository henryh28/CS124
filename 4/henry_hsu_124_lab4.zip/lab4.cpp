#include <iostream>
#include <list>
#include "date.cpp"
using namespace std;



string main_menu()
{
	string menu_option;

	cout << "--------------------------------" << endl;
	cout << "Welcome to Homework Tracker v1.0" << endl;
	cout << "--------------------------------" << endl;
	cout << left << setw(38) << "A)dd a new assignment" ;
	cout << "R)emove an assignment" << endl;
	cout << left << setw(38) << "L)ist assignments in order assigned";
	cout << "F)ind assignment with earliest due date" << endl;
	cout << "Q)uit" << endl;
	cin >> menu_option;
	cout << endl;
	menu_option[0] = toupper(menu_option [0]);
	menu_option.resize(1);
	return menu_option;
}


void add_assignment(list <string>& hw_desc, list <Date>& hw_assign, list <Date>& hw_due)
{
	string input_description;
	Date input_assigned, input_due;
	cout << "Enter a short description for the assignment: ";
	cin >> input_description;
	cout << "Enter the date that this assignment was assigned: ";
	cin >> input_assigned;
	cout << "Enter the date that this assignemnt is due: ";
	cin >> input_due;

	hw_desc.push_back(input_description);
	hw_assign.push_back(input_assigned);
	hw_due.push_back(input_due);
}


void list_assignments(list <string>& hw_desc, list <Date>& hw_assign, list <Date>& hw_due)
{
	list<string>::iterator iter;

	int k = hw_desc.size();
	for (iter = hw_desc.begin(); iter != hw_desc.end(); iter++)
	{
// 		hw_tracker(1)->Display_Assigned(&hw_tracker);
	}
}


void remove_assignment(list <string>& hw_desc, list <Date>& hw_assign, list <Date>& hw_due)
{
	string erase;
	cout << "Enter the name of the assignment that you want to remove: " ;
	cin >> erase;

	list<string>::iterator iter;

/**
for (iter = hw_desc.begin(); iter != hw_desc.end(); iter++)
	{
		if (erase== hw_desc())
		{

		}
	}
*/

	//	hw_tracker.pop_back();
}


void find_earliest(list <string>& hw_desc, list <Date>& hw_assign, list <Date>& hw_due)
{
	hw_due.sort();
	list<Date>::iterator iter;

	for (iter = hw_due.begin(); iter != hw_due.end(); iter++)
	{
		cout << "The assignment that is due the soonest is on " << *iter << " !!!" << endl;
		break;
	}
}

int main ()
{
	list <string> hw_desc;
	list <Date> hw_due;
	list <Date> hw_assign;

	string menu_option;

	while (menu_option != "Q")
	{
		menu_option = main_menu();

		if (menu_option == "A")
		{
			add_assignment(hw_desc, hw_assign, hw_due);
		}
		else if (menu_option == "R")
		{
			remove_assignment(hw_desc, hw_assign, hw_due);
		}
		else if (menu_option == "L")
		{
			list_assignments(hw_desc, hw_assign, hw_due);
		}
		else if (menu_option == "F")
		{
			find_earliest(hw_desc, hw_assign, hw_due);
		}
	}
cout << "Thank you for using Homework Tracker v1.0" << endl;
}
