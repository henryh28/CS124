#include <iostream>
#include <list>
#include <iomanip>
#include "date.cpp"

using namespace std;


class Lab
{
	public:
		Lab();
		Lab(string description, Date assigned, Date due);
		void Display_Assigned(list <Lab>& hw_tracker);
		void Output();

		Date Return_Date();
		Date Return_Assigned();
		string Return_Desc();

	private:
		string m_description;
		Date m_due;
		Date m_assigned;
};

Lab::Lab () {}

Lab::Lab (string description, Date assigned, Date due)
{
	m_description = description;
	m_assigned = assigned;
	m_due = due;
}

void Lab::Output()
{
	cout << left << setw(30) << m_description ;
	cout << right << setw(15) << m_assigned ;
	cout << "     " ;
	cout << right << setw(15) << m_due ;
	cout << endl;
}

Date Lab::Return_Date() {return m_due;}
Date Lab::Return_Assigned() {return m_assigned;}
string Lab::Return_Desc() {return m_description;}


void Lab::Display_Assigned(list <Lab>& hw_tracker)
{
	cout << left << setw(30) << m_description ;
	cout << right << setw(15) << m_assigned ;
	cout << "     " ;
	cout << right << setw(15) << m_due ;
	cout << endl;
}

string main_menu()
{
	string menu_option;
	cout << endl;
	cout << "----------------------------------------------------------" << endl;
	cout << "              Welcome to Homework Tracker v1.0            " << endl;
	cout << "----------------------------------------------------------" << endl;
	cout << left << setw(38) << "A)dd a new assignment" ;
	cout << "R)emove an assignment" << endl;
	cout << left << setw(38) << "L)ist assignments in order assigned";
	cout << "F)ind assignment with earliest due date" << endl;
	cout << "Q)uit" << endl;
	cin >> menu_option;
	cout << endl;
	menu_option[0] = toupper(menu_option [0]);
	menu_option.resize(1);
	return menu_option;
}


void add_assignment(list <Lab>& hw_tracker)
{
	string input_description;
	Date input_assigned, input_due;

	cout << "Enter a short description for the assignment: ";
	cin >> input_description;
	cout << "Enter the date that this assignment was assigned: ";
	cin >> input_assigned;
	cout << "Enter the date that this assignemnt is due: ";
	cin >> input_due;

	Lab assignment (input_description, input_assigned, input_due);
	hw_tracker.push_back(assignment);
}


void list_assignments(list <Lab>& hw_tracker)
{
	list<Lab>::iterator iter;

	for (iter = hw_tracker.begin(); iter != hw_tracker.end(); iter++)
	{
		iter->Display_Assigned(hw_tracker);
	}

}


void remove_assignment(list <Lab>& hw_tracker)
{
	string erase;
	list<Lab>::iterator iter;

	cout << "Enter the name of the assignment that is to be deleted: ";
	cin >> erase;

	for (iter = hw_tracker.begin(); iter != hw_tracker.end(); iter++)
	{
		if (iter->Return_Desc() == erase)
		{
			hw_tracker.erase(iter);
			break;
		}
	}
}


void find_earliest(list <Lab>& hw_tracker)
{
	list<Lab>::iterator iter;
	Date today;
	list <Lab> secondary;
	Lab print ;

	for (iter = hw_tracker.begin(); iter != hw_tracker.end(); iter++)
	{
		if (iter->Return_Date() > today)
		{
			secondary.push_back(*iter);
		}
		else {}
	}

	print = secondary.front();

	for (iter = secondary.begin(); iter != secondary.end(); iter++)
	{

		if (iter->Return_Date() > (iter++)->Return_Date())
		{
			// do nothing;
		}
		else
		{
			if (iter->Return_Date() < print.Return_Date())
			print = *iter;
		}
	}
	cout << "The next assignment that is due is: " << endl;
	print.Output();
}


int main ()
{
	list <Lab> hw_tracker;
	string menu_option;

	while (menu_option != "Q")
	{
		menu_option = main_menu();		// done
		if (menu_option == "A")
		{
			add_assignment(hw_tracker);
		}
		else if (menu_option == "R")	// done
		{
			remove_assignment(hw_tracker);
		}
		else if (menu_option == "L")
		{
			list_assignments(hw_tracker);
		}
		else if (menu_option == "F")	// done
		{
			find_earliest(hw_tracker);
		}
	}
cout << endl << "Thank you for using Homework Tracker v1.0" << endl;
}


